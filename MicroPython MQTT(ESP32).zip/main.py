"""
MicroPython IoT Weather Station Example for Wokwi.com

To view the data:

1. Go to http://www.hivemq.com/demos/websocket-client/
2. Click "Connect"
3. Under Subscriptions, click "Add New Topic Subscription"
4. In the Topic field, type "wokwi-weather" then click "Subscribe"

Now click on the DHT22 sensor in the simulation,
change the temperature/humidity, and you should see
the message appear on the MQTT Broker, in the "Messages" pane.

Copyright (C) 2022, Uri Shaked

https://wokwi.com/arduino/projects/322577683855704658
"""
import network
import time
from umqtt.simple import MQTTClient
import dht
from machine import Pin

# WiFi
wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect("Wokwi-GUEST", "")

while not wlan.isconnected():
    time.sleep(1)

print("WiFi connected:", wlan.ifconfig())

# MQTT
client = MQTTClient("esp32", "broker.hivemq.com")
client.connect()
print("Connected to MQTT broker")

# DHT22 GPIO 15 (ou pin correspondant)
sensor = dht.DHT22(Pin(15))

while True:
    try:
        sensor.measure()
        temperature = sensor.temperature()
        humidity = sensor.humidity()

        # 🔥 Fire (1 / 0)
        fire = 1 if temperature > 50 else 0
        # 💧 Water Level (100 / 0)
        waterlevel = 100 if humidity > 60 else 0
        # 🌊 Flood (50 / 0)
        flood = 50 if humidity > 80 else 0

        # Publish MQTT uniquement
        client.publish(b"sensors/fire", str(fire))
        client.publish(b"sensors/waterlevel", str(waterlevel))
        client.publish(b"sensors/floodlevel", str(flood))

        # Print simplifié pour confirmer l'envoi
        print("MQTT sent -> Fire:", fire, "| Water:", waterlevel, "| Flood:", flood)

    except OSError as e:
        print("Sensor error, retrying...", e)
        time.sleep(2)
        continue

    time.sleep(5)
