"""
MicroPython IoT Weather Station Example for Wokwi.com

To view the data:

1. Go to http://www.hivemq.com/demos/websocket-client/
2. Click "Connect"
3. Under Subscriptions, click "Add New Topic Subscription"
4. In the Topic field, type "wokwi-weather" then click "Subscribe"

Now click on the DHT22 sensor in the simulation,
change the temperature/humidity, and you should see
the message appear on the MQTT Broker, in the "Messages" pane.

Copyright (C) 2022, Uri Shaked

https://wokwi.com/arduino/projects/322577683855704658
"""
import network
import time
import random
from umqtt.simple import MQTTClient

wlan = network.WLAN(network.STA_IF)
wlan.active(True)
wlan.connect("Wokwi-GUEST", "")

print("Connecting to WiFi...")
while not wlan.isconnected():
    time.sleep(1)
print("WiFi connected:", wlan.ifconfig())


client = MQTTClient("esp32", "broker.hivemq.com")
client.connect()
print("Connected to MQTT broker")


while True:
    water = random.randint(0, 100)
    flood = random.randint(0, 50)
    fire = random.randint(0, 1)

    
    client.publish(b"sensors/waterlevel", str(water))
    client.publish(b"sensors/floodlevel", str(flood))
    client.publish(b"sensors/fire", str(fire))

    print("Sent -> Water:", water, "Flood:", flood, "Fire:", fire)
    time.sleep(3)

